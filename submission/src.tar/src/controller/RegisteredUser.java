package controller;
/**
 *        File Name: RegisteredUser.java
 *        Assignment: Term project
 *        Lab section: B01
 *        Completed by: Chun-chun Huang
 *        Submission Date: Dec 5 2022
 */
public class RegisteredUser extends User {



    public RegisteredUser(String email, String password) {
        super(email,password,"registered");

    }


}
