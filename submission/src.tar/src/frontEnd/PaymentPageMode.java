package frontEnd;

public enum PaymentPageMode {
    REGISTRATION,
    TICKET_ORDER_VISITOR,
    TICKET_ORDER_USER
}
