package frontEnd;
/**
 *        File Name: Admin_page.java
 *        Assignment: Term project
 *        Lab section: B01
 *        Completed by: Siddharth Menon
 *        Submission Date: Dec 5 2022
 */
import javax.swing.*;
  
class ErrorPage extends JFrame  //eror window when users make invalid inputs
{  
    ErrorPage()  
    {  
        setDefaultCloseOperation(javax.swing.  
        WindowConstants.DISPOSE_ON_CLOSE);  
        setTitle("Select from available movies: ");  
        setSize(400, 200);  
    }  
}
